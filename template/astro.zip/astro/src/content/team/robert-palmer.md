---
draft: false
name: "Robert Palmer"
title: "Marketing Engineer"
avatar: {
    src: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?&fit=crop&w=280",
    alt: "Robert Palmer"
}
publishDate: "2022-11-09 15:39"
---
